package com.easyapproach.contact_google_sign_in

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
